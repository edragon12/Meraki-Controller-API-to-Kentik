# Troubleshooting

## `can't open file '.../collector.py': No such file or directory`
You are running the command from the wrong folder. `cd` into the project folder first and confirm with `ls -a`:

```bash
cd ~/Downloads/Meraki-Kentik
ls -a        # should list collector.py and .env
python3 collector.py --mode real --dry-run
```

## `zsh: bad pattern: [200~...` after pasting a command
Terminal bracketed paste added a hidden marker. Run `unset zle_bracketed_paste`, or type the command instead of pasting it.

## `zsh: command not found: rg`
`rg` (ripgrep) is optional. Use macOS `grep` instead, for example `python3 collector.py --mode mock --dry-run | grep last_connected`.

## `MERAKI_API_KEY and MERAKI_ORG_ID are required`
The `.env` file is missing or in a different folder. Create it with `cp .env.example .env`, `chmod 600 .env`, then edit it. The release packages never include `.env`.

## `unrecognized arguments: python3 collector.py`
Two commands were pasted on one line. Run only one command at a time.

## HTTP 401 / 403 from Meraki
The API key is invalid, revoked, or lacks access to the organization. Generate a new key in the Meraki Dashboard and update `MERAKI_API_KEY`.

## HTTP 429 or repeated retries
Meraki is rate limiting. The collector honors `Retry-After` and retries with backoff. Increase `--interval`, lower `MAX_WIRELESS_CLIENTS`, or raise `HTTP_RETRY_BACKOFF_SECONDS`.

## Kentik ingest returns an HTTP error
Check `KENTIK_INGEST_URL` (including the `bucket` and `org` values), `KENTIK_EMAIL`, and `KENTIK_API_TOKEN`. Test with `--dry-run` first to separate Meraki problems from Kentik problems.

## Dry-run shows 0 `meraki_wireless_client` lines
Meraki returned no wireless clients inside the lookback window. Increase `MERAKI_CLIENT_TIMESPAN` (for example `604800` for 7 days).

## `last_connected` is not visible in Kentik
`last_connected` is a **dimension**. A saved Kentik panel only shows the dimensions it was built with, so add it by hand:
1. Confirm the collector emits it: `python3 collector.py --mode real --dry-run | grep -o 'last_connected=[^,]*' | head -3`
2. Send data: `python3 collector.py --mode real`
3. Wait a few minutes, then edit the panel and add `last_connected` in the **Dimensions** pane.

`last_connected=unknown` means Meraki did not return a usable `lastSeen` for that client.

## "Last connected" shows `0.00` or `1.00`
That is the numeric `connected` metric (true/false). Use the `last_connected` dimension for a readable date.

## Too many rows or stale rows in the client table
Each distinct `last_connected` value is a separate series. Raise `LAST_CONNECTED_ROUND_SECONDS` (`3600` hourly, `86400` daily) to reduce churn.
